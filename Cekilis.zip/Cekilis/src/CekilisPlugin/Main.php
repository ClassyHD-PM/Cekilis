<?php

namespace CekilisPlugin;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use jojoe77777\FormAPI\SimpleForm;
use jojoe77777\FormAPI\CustomForm;
use onebone\economyapi\EconomyAPI;
use pocketmine\scheduler\Task;

class Main extends PluginBase {

    private Config $cekilisConfig;

    public function onEnable(): void {
        @mkdir($this->getDataFolder());
        $this->cekilisConfig = new Config($this->getDataFolder() . "cekilis.yml", Config::YAML, [
            "aktif" => false,
            "odul" => 0,
            "bitis_zamani" => 0,
            "katilimcilar" => [],
        ]);

        $this->getScheduler()->scheduleRepeatingTask(new class($this) extends Task {
            private Main $plugin;
            public function __construct(Main $plugin) {
                $this->plugin = $plugin;
            }
            public function onRun(): void {
                $this->plugin->cekilisKontrol();
            }
        }, 20);
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if (!$sender instanceof Player) {
            $sender->sendMessage("Bu komutu sadece oyuncular kullanabilir.");
            return true;
        }

        switch ($command->getName()) {
            case "cekilisyap":
                if (!$sender->hasPermission("cekilis.admin")) {
                    $sender->sendMessage("§cBu komutu kullanmaya yetkiniz yok.");
                    return true;
                }
                $this->openCekilisYapForm($sender);
                return true;

            case "cekilis":
                if (!$sender->hasPermission("cekilis.use")) {
                    $sender->sendMessage("§cBu komutu kullanmaya yetkiniz yok.");
                    return true;
                }
                $this->openCekilisForm($sender);
                return true;
        }
        return false;
    }

    private function openCekilisYapForm(Player $player): void {
        $form = new CustomForm(function(Player $player, $data) {
            if ($data === null) return;

            $odul = (int)$data[0];
            $gun = (int)$data[1];

            if ($odul <= 0 || $gun <= 0) {
                $player->sendMessage("§cGeçerli bir ödül ve gün sayısı girin.");
                return;
            }

            $bitisZamani = time() + ($gun * 86400);

            $this->cekilisConfig->setAll([
                "aktif" => true,
                "odul" => $odul,
                "bitis_zamani" => $bitisZamani,
                "katilimcilar" => [],
            ]);
            $this->cekilisConfig->save();

            $player->sendMessage("§aÇekiliş oluşturuldu! Ödül: {$odul} TL, {$gun} gün sonra açıklanacak.");
        });

        $form->setTitle("Çekiliş Yap");
        $form->addInput("Para Ödülü", "örn: 50000");
        $form->addInput("Açıklanacak Gün Sayısı", "örn: 3");

        $player->sendForm($form);
    }

    private function openCekilisForm(Player $player): void {
        if (!$this->cekilisConfig->get("aktif", false)) {
            $player->sendMessage("§cŞu anda aktif bir çekiliş yok.");
            return;
        }

        $odul = $this->cekilisConfig->get("odul", 0);
        $bitisZamani = $this->cekilisConfig->get("bitis_zamani", 0);
        $katilimcilar = $this->cekilisConfig->get("katilimcilar", []);

        $kalanSure = $bitisZamani - time();
        if ($kalanSure < 0) $kalanSure = 0;

        $gun = floor($kalanSure / 86400);
        $saat = floor(($kalanSure % 86400) / 3600);

        $form = new SimpleForm(function(Player $player, $data) {
            if ($data === null) return;

            if ($data === 0) {
                $this->cekiliseKatil($player);
            }
        });

        $form->setTitle("Çekiliş Menüsü");
        $form->setContent("§fPara Ödülü:§a {$odul} §fTL\n§fAçıklanacak Gün:§a {$gun} §fGün §a{$saat} §fSaat\n\n§fÇekilişe Katılma Ücreti: §a12500 §fTL");
        $form->addButton("Çekilişe Katıl");

        $player->sendForm($form);
    }

    private function cekiliseKatil(Player $player): void {
        if (!$this->cekilisConfig->get("aktif", false)) {
            $player->sendMessage("§cŞu anda aktif bir çekiliş yok.");
            return;
        }

        $katilimcilar = $this->cekilisConfig->get("katilimcilar", []);
        $isim = $player->getName();

        if (in_array($isim, $katilimcilar)) {
            $player->sendMessage("§cZaten çekilişe katıldınız.");
            return;
        }

        $economy = EconomyAPI::getInstance();
        $ucret = 12500;

        if ($economy->myMoney($player) < $ucret) {
            $player->sendMessage("§cYeterli paranız yok! Gerekli: {$ucret} TL");
            return;
        }

        $economy->reduceMoney($player, $ucret);

        $katilimcilar[] = $isim;
        $this->cekilisConfig->set("katilimcilar", $katilimcilar);
        $this->cekilisConfig->save();

        $player->sendMessage("§aÇekilişe katıldınız! İyi şanslar!");
    }

    public function cekilisKontrol(): void {
        if (!$this->cekilisConfig->get("aktif", false)) return;

        $bitisZamani = $this->cekilisConfig->get("bitis_zamani", 0);

        if (time() >= $bitisZamani) {
            $katilimcilar = $this->cekilisConfig->get("katilimcilar", []);
            $odul = $this->cekilisConfig->get("odul", 0);

            if (count($katilimcilar) === 0) {
                $this->getLogger()->info("Çekiliş iptal edildi: Katılımcı yok.");
            } else {
                $kazananIsim = $katilimcilar[array_rand($katilimcilar)];
                $player = $this->getServer()->getPlayerExact($kazananIsim);
                $economy = EconomyAPI::getInstance();

                if ($player !== null) {
                    $economy->addMoney($player, $odul);
                    $player->sendMessage("§aTebrikler! Çekilişi kazandınız ve {$odul} TL kazandınız!");
                }

                $this->getServer()->broadcastMessage("§6Çekiliş sonuçlandı! Kazanan: {$kazananIsim}, Ödül: {$odul} TL");
            }

            $this->cekilisConfig->setAll([
                "aktif" => false,
                "odul" => 0,
                "bitis_zamani" => 0,
                "katilimcilar" => [],
            ]);
            $this->cekilisConfig->save();
        }
    }
}